from odoo import models, fields, api

class student(models.Model):
	_name = 'student.student'
	_description = 'student.student'

	name = fields.Char()
