    $(document).ready(function() {
          $('#add_academic_row_btn').click(function() {
            // Create a new table row element
            const newRow = document.createElement('tr');

            // Create table cells for each field
            const nameCell = document.createElement('td');
            const studyFieldCell = document.createElement('td');
            const organizationCell = document.createElement('td');
            const startDateCell = document.createElement('td');
            const endDateCell = document.createElement('td');
            const gradeCell = document.createElement('td');
            const deleteCell = document.createElement('td');

            // Add input elements for data entry (optional)
            nameCell.innerHTML = '<input type="text" class="responsive-input" name="new_field_name"/>';
            studyFieldCell.innerHTML = '<input type="text" class="responsive-input" name="new_study_field"/>';
            organizationCell.innerHTML = '<input type="text" class="responsive-input" name="new_organization"/>';
            startDateCell.innerHTML = '<input type="date" class="responsive-input" name="new_start_date"/>'; 
            endDateCell.innerHTML = '<input type="date" class="responsive-input" name="new_end_date"/>'; 
            gradeCell.innerHTML = '<input type="text" class="responsive-input" name="new_grade"/>';

            // Create and add a delete button to the delete cell
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Remove'; // Button text customization
            deleteButton.classList.add('btn', 'btn-sm', 'btn-danger'); // Button styling (Bootstrap)
            deleteCell.appendChild(deleteButton);

            // Append cells to the new row
            newRow.appendChild(nameCell);
            newRow.appendChild(studyFieldCell);
            newRow.appendChild(organizationCell);
            newRow.appendChild(startDateCell);
            newRow.appendChild(endDateCell);
            newRow.appendChild(gradeCell);
            newRow.appendChild(deleteCell);

            // Append the new row to the table body
            $('#academic_info_table tbody').append(newRow);

            // Attach a click event listener to the delete button
            deleteButton.addEventListener('click', function() {
              $(this).closest('tr').remove(); // Remove the entire row
              });
          });
        });


        $(document).ready(function() {
          $('#add_professional_row_btn').click(function() {
            // Create a new table row element
            const newRow = document.createElement('tr');

            // Create table cells for each field
            const nameCell = document.createElement('td');
            const organizationCell = document.createElement('td');
            const startDateCell = document.createElement('td');
            const endDateCell = document.createElement('td');
            const descCell = document.createElement('td');
            const deleteCell = document.createElement('td');

            // Add input elements for data entry (optional)
            nameCell.innerHTML = '<input type="text" class="responsive-input" name="new_name"/>';
            organizationCell.innerHTML = '<input type="text" class="responsive-input" name="new_p_organization"/>';
            startDateCell.innerHTML = '<input type="date" class="responsive-input" name="new_p_start_date"/>'; 
            endDateCell.innerHTML = '<input type="date" class="responsive-input" name="new_p_end_date"/>'; 
            descCell.innerHTML = '<input type="text" class="responsive-input" name="new_desc"/>'; 
           

            // Create and add a delete button to the delete cell
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Remove'; // Button text customization
            deleteButton.classList.add('btn', 'btn-sm', 'btn-danger'); // Button styling (Bootstrap)
            deleteCell.appendChild(deleteButton);

            // Append cells to the new row
            newRow.appendChild(nameCell);
            newRow.appendChild(organizationCell);
            newRow.appendChild(startDateCell);
            newRow.appendChild(endDateCell);
            newRow.appendChild(descCell);
            newRow.appendChild(deleteCell);

            // Append the new row to the table body
            $('#professional_info_table tbody').append(newRow);

            // Attach a click event listener to the delete button
            deleteButton.addEventListener('click', function() {
              $(this).closest('tr').remove(); // Remove the entire row
              });
          });
        });