import ast
from odoo import models, fields, api


class JobPosting(models.Model):
    _name = 'job.posting'
    _description = 'prediction'
    _inherit = ["mail.alias.mixin","hr.job"]
    _order = "sequence, name asc"

    user_id = fields.Many2one('res.users', "Recruiter", domain="[('share', '=', False), ('company_ids', 'in', company_id)]", tracking=True, help="The Recruiter will be the default value for all Applicants Recruiter's field in this job position. The Recruiter is automatically added to all meetings with the Applicant.")
    interviewer_ids = fields.Many2many('res.users', string='Interviewers', domain="[('share', '=', False), ('company_ids', 'in', company_id)]", help="The Interviewers set on the job position can see all Applicants in it. They have access to the information, the attachments, the meeting management and they can refuse him. You don't need to have Recruitment rights to be set as an interviewer.")
    address_id = fields.Many2one(
        'res.partner', "Job Location",
        help="Select the location where the applicant will work. Addresses listed here are defined on the company's contact information.")
    alias_id = fields.Many2one(help="Email alias for this job position. New emails will automatically create new applicants for this job position.")
    is_favorite=fields.Boolean()
    color=fields.Integer("color Index")
    new_application_count=fields.Integer(string='New Application')
    manager_id = fields.Many2one(
        'hr.employee', related='department_id.manager_id', string="Department Manager",
        readonly=True, store=True)
    application_ids=fields.One2many('prediction.applicant','job_id',"Job Applications")
    application_count = fields.Integer(string="Application Count")
    is_published=fields.Boolean()
    activities_today = fields.Integer()
    activities_overdue = fields.Integer()
    website_published=fields.Boolean()
    application_email=fields.Char()
    applicant_properties_definition = fields.PropertiesDefinition('Applicant Properties')
    favorite_user_ids = fields.Many2many('res.users', 'job_favorite_users_rel', 'job_posting_id', 'user_id')
    all_application_count = fields.Integer(compute='_compute_all_application_count', string="All Application Count")
    documents_count = fields.Integer(compute='_compute_document_ids', string="Document Count")


    def close_dialog(self):
        pass


    def _alias_get_creation_values(self):
        values = super(JobPosting, self)._alias_get_creation_values()
        values['alias_model_id'] = self.env['ir.model']._get('prediction.applicant').id
        if self.id:
            values['alias_defaults'] = defaults = ast.literal_eval(self.alias_defaults or "{}")
            defaults.update({
                'job_id': self.id,
                'department_id': self.department_id.id,
                'company_id': self.department_id.company_id.id if self.department_id else self.company_id.id,
                'user_id': self.user_id.id,
            })
        return values


    def action_open_attachments(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'ir.attachment',
            'name': _('Documents'),
            'context': {
                'default_res_model': self._name,
                'default_res_id': self.ids[0],
                'show_partner_name': 1,
            },
            'view_mode': 'tree',
            'views': [
                (self.env.ref('prediction.ir_attachment_hr_recruitment_list_view').id, 'tree')
            ],
            'search_view_id': self.env.ref('prediction.ir_attachment_view_search_inherit_hr_recruitment').ids,
            'domain': ['|',
                '&', ('res_model', '=', 'job.posting'), ('res_id', 'in', self.ids),
                '&', ('res_model', '=', 'prediction.applicant'), ('res_id', 'in', self.application_ids.ids),
            ],
        }
        

    def write(self, vals):
        old_interviewers = self.interviewer_ids
        if 'active' in vals and not vals['active']:
            self.application_ids.active = False
        res = super().write(vals)
        if 'interviewer_ids' in vals:
            interviewers_to_clean = old_interviewers - self.interviewer_ids
            interviewers_to_clean._remove_recruitment_interviewers()
            self.sudo().interviewer_ids._create_recruitment_interviewers()

        # Since the alias is created upon record creation, the default values do not reflect the current values unless
        # specifically rewritten
        # List of fields to keep synched with the alias
        alias_fields = {'department_id', 'user_id'}
        if any(field for field in alias_fields if field in vals):
            for job in self:
                alias_default_vals = job._alias_get_creation_values().get('alias_defaults', '{}')
                job.alias_defaults = alias_default_vals
        return res

    def _compute_all_application_count(self):
        read_group_result = self.env['prediction.applicant'].with_context(active_test=False)._read_group([
            ('job_id', 'in', self.ids),
            '|',
            ('active', '=', True),
            '&',
            ('active', '=', False), ('refuse_reason_id', '!=', False),
            ], ['job_id'], ['__count'])
        result = {job.id: count for job, count in read_group_result}
        for job in self:
            job.all_application_count = result.get(job.id, 0)

    def _compute_document_ids(self):
        applicants = self.mapped('application_ids').filtered(lambda self: not self.emp_id)
        app_to_job = dict((applicant.id, applicant.job_id.id) for applicant in applicants)
        attachments = self.env['ir.attachment'].search([
            '|',
            '&', ('res_model', '=', 'job.posting'), ('res_id', 'in', self.ids),
            '&', ('res_model', '=', 'prediction.applicant'), ('res_id', 'in', applicants.ids)])
        result = dict.fromkeys(self.ids, self.env['ir.attachment'])
        for attachment in attachments:
            if attachment.res_model == 'prediction.applicant':
                result[app_to_job[attachment.res_id]] |= attachment
            else:
                result[attachment.res_id] |= attachment

        for job in self:
            job.document_ids = result.get(job.id, False)
            job.documents_count = len(job.document_ids)