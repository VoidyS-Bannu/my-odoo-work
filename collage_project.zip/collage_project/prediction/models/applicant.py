from odoo import api, fields, models, tools, SUPERUSER_ID
import base64   
import fitz
import nltk

AVAILABLE_PRIORITIES = [
    ('0', 'Normal'),
    ('1', 'Good'),
    ('2', 'Very Good'),
    ('3', 'Excellent')
]
class Applicant(models.Model):
    _name = "prediction.applicant"
    _description = "Applicant"
    _inherit = ['mail.thread.cc',
               'mail.thread.main.attachment',
               'mail.thread.blacklist',
               'mail.thread.phone',
               'mail.activity.mixin',
               'utm.mixin']
    _mailing_enabled = True
    _primary_email = 'email_from'

    name = fields.Char("Subject / Application",default="New Applicant", help="Email subject for applications sent via email", index='trigram')
    active = fields.Boolean("Active", default=True, help="If the active field is set to false, it will allow you to hide the case without removing it.")
    partner_id = fields.Many2one('res.partner', "Contact", copy=False)
    # application_id=fields.Many2one('website.applicant')
    partner_name=fields.Char("Applicant's Name")
    email_from = fields.Char("Email",store=True)
    partner_phone=fields.Char("Phone Number")
    partner_mobile=fields.Char("Mobile Numer")
    linkedin_profile=fields.Char("LinkedIn Profile")
    type_id = fields.Char(string="degree")
    interviewer_ids=fields.Selection([('hr','HR'),('senior_developer','Senior Developer')])
    meeting_display_text=fields.Char()
    meeting_display_date=fields.Char()
    medium_id = fields.Many2one(ondelete='set null')
    source_id = fields.Many2one(ondelete='set null')
    availability = fields.Date("Availability", help="The date at which the applicant will be available to start working", tracking=True)
    resume_detail= fields.Char()
    resume = fields.Many2many('ir.attachment', string="Attachments")
    description=fields.Html("Description")
    stage_id=fields.Selection([('new','New'),('in_progress','In Progress'),('ready_for_next_stage','Ready for next Stage')])
    job_id = fields.Many2one('job.posting', "Applied Job", domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]", tracking=True, index=True)
    attachment_ids = fields.One2many('ir.attachment', 'res_id', domain=[('res_model', '=', 'prediction.applicant')], string='Attachments')
    work_sample=fields.Text()
    reason=fields.Text()
    reference=fields.Char()
    shift_time_id=fields.Selection([
                                    ('8am to 2pm', '(8am to 2pm)'),
                                    ('2pm to 9pm', '(2pm to 9pm)'),
                                    ('9pm to 3am', '(9pm to 3am)')])
    color = fields.Integer("Color Index", default=0)
    priority = fields.Selection(AVAILABLE_PRIORITIES, "Evaluation", default='0')
    department_id = fields.Many2one(
        'hr.department', "Department",  store=True, readonly=False,
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]", tracking=True)
    attachment_number = fields.Integer(string="Number of Attachments")
    application_status = fields.Selection([
        ('ongoing', 'Ongoing'),
        ('hired', 'Hired'),
        ('refused', 'Refused'),
        ('archived', 'Archived'),
    ])
    references=fields.Char(string="reference")
    company_id = fields.Many2one('res.company', "Company", store=True, readonly=False, tracking=True)
    applicant_properties = fields.Properties('Properties', definition='job_id.applicant_properties_definition', copy=True)
    extracted_keywords = fields.Text(string="Extracted Keywords")
    current_address = fields.Char(string="current address")
    new_field_name=fields.Char(string="fields' name")
    new_study_field=fields.Char(string="study fields")
    new_organization=fields.Char(string="organization")
    new_start_date=fields.Date(string="start date")
    new_end_date=fields.Date(string="end date")
    new_grade=fields.Char(string="grade")
    new_name=fields.Char(string="role of profession")
    new_desc=fields.Text(string="description of profession")
    new_p_start_date=fields.Date(string="start date of profession's")
    new_p_end_date=fields.Date(string="end date of profession's")
    new_p_organization=fields.Char(string="profession's organization")
    create_date = fields.Datetime("Applied on", readonly=True)

    def create_employee_from_applicant(self):
        pass

    def toggle_active(self):
        pass

    def action_open_employee(self):
        pass

    def action_applications_email(self):
        pass

    def action_makeMeeting(self):
        pass


    def action_open_attachments(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'ir.attachment',
            'name': _('Documents'),
            'context': {
                'default_res_model': 'hr.job',
                'default_res_id': self.ids[0],
                'show_partner_name': 1,
            },
            'view_mode': 'tree,form',
            'views': [
                (self.env.ref('prediction.ir_attachment_job_posting_list_view').id, 'tree'),
                (False, 'form'),
            ],
            'search_view_id': self.env.ref('prediction.ir_attachment_view_search_inherit_hr_recruitment').ids,
            'domain': [('res_model', '=', 'prediction.applicant'), ('res_id', 'in', self.ids), ],
        }

    def extract_pdf(self):
        target_keywords = ["python", "django", "flask", "numpy", "pandas", "matplotlib",
                            "scikit-learn", "tensorflow", "pytorch", "html", "css", "javascript",
                            "sql", "postgresql", "mysql", "mongodb", "git", "pytest", "unittest",
                            "api", "restful", "soap", "aws", "gcp", "azure", "docker", "kubernetes","english"]


        for record in self:
            pdf_content = record.resume
            if pdf_content:
                pdf_content = base64.b64decode(pdf_content)
                pdf_document = fitz.open("pdf", pdf_content)
                text = ""

                for page_num in range(pdf_document.page_count):
                    page = pdf_document[page_num]
                    text += page.get_text()

                pdf_document.close()

                
                tokens = nltk.word_tokenize(text)
                # Convert target keywords to lowercase for case-insensitive matching
                lower_target_keywords = [kw.lower() for kw in target_keywords]
                # Use a set to store unique extracted keywords
                extracted_keywords = {word.lower() for word in tokens if word.lower() in lower_target_keywords}

                # Update the new field (convert set back to list if needed)
                record.extracted_keywords = ", ".join(extracted_keywords)

                print(extracted_keywords)

                if extracted_keywords:
                    print("application is able")
                else:
                    print("refuse")

