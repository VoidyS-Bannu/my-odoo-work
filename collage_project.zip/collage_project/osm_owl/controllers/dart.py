from odoo import http
from odoo.http import request, route

class Dart(http.Controller):
    @http.route(['/dart'],type="http",auth="public")
    def dart(self):
        return request.render('osm_owl.charg')

