{
    'name':'Odoo Owl',

    'author':'sid',

    'data': [
        'views/templates.xml',
        ],

    'assets':{
        'osm_owl.assets_charge':[
            # bootstrap
            ('include', 'web._assets_helpers'),
            'web/static/src/scss/pre_variables.scss',
            'web/static/lib/bootstrap/scss/_variables.scss',
            ('include', 'web._assets_bootstrap_backend'),

            # required for fa icons
            'web/static/src/libs/fontawesome/css/font-awesome.css',
            
            # include base files from framework
            ('include', 'web._assets_core'),

            'web/static/src/core/utils/functions.js',
            'web/static/src/core/browser/browser.js',
            'web/static/src/core/registry.js',
            'web/static/src/core/assets.js',
            'osm_owl/static/src/**/*',
        ]
    } ,

    'license': 'AGPL-3',
}