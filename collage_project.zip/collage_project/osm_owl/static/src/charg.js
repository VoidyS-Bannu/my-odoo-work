/** @odoo-module **/

import { Component } from "@odoo/owl";

export class Charg extends Component{
    static template = "osm_owl.charg";
    
}