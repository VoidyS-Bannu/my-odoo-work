/** @odoo-module **/

import { browser } from "@web/core/browser/browser";
import { mount, whenReady } from "@odoo/owl";
import { Charg } from "./charg";
import { templates } from "@web/core/assets";

whenReady(()=>{ 
    mount(Charg, document.body,{templates, dev:true,name:"First OWl Comopents"});
});
