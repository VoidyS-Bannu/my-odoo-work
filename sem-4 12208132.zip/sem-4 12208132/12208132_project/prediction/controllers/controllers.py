# -*- coding: utf-8 -*-
# from odoo import http


# class Prediction(http.Controller):
#     @http.route('/prediction/prediction', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/prediction/prediction/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('prediction.listing', {
#             'root': '/prediction/prediction',
#             'objects': http.request.env['prediction.prediction'].search([]),
#         })

#     @http.route('/prediction/prediction/objects/<model("prediction.prediction"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('prediction.object', {
#             'object': obj
#         })

