# -*- coding: utf-8 -*-
{
    'name': "prediction",

    'summary': "Short (1 phrase/line) summary of the module's purpose",

    'description': """
Long description of module's purpose
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['hr',
        'calendar',
        'utm',
        'attachment_indexation',
        'web_tour',
        'digest',],

    # always loaded
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/stage_data.xml',
        'views/applicant_view.xml',
        'views/JobPosting.xml',
        'views/templates.xml',
        'views/skill_view.xml',
        'views/attachment.xml',
        'views/source.xml',
        'views/stage.xml',
        'views/refuse.xml',
        'views/callrequest.xml',
        'wizard/refuse_reason_wizard.xml'
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}

