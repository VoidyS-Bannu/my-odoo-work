# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError


class ApplicantGetRefuseReason(models.TransientModel):
    _name = 'get.refuse.reason'
    _description = 'Get Refuse Reason'

    refuse_reason_id = fields.Many2one('refuse.reason', 'Refuse Reason')
    applicant_ids = fields.Many2many('prediction.applicant')
   

    @api.depends('applicant_ids.email_from')
    def _compute_applicant_emails(self):
        for wizard in self:
            wizard.applicant_emails = ', '.join(a.email_from for a in wizard.applicant_ids if a.email_from)

    def action_refuse_reason_apply(self):
        self.applicant_ids.write({'refuse_reason_id': self.refuse_reason_id.id, 'active': False})
        