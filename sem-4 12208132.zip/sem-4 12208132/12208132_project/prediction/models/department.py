# -*- coding: utf-8 -*-

from odoo import fields, models


class Department(models.Model):
    _inherit = 'hr.department'

    new_applicant_count = fields.Integer()
    new_hired_employee = fields.Integer(string='New Hired Employee')
    expected_employee = fields.Integer(string='Expected Employee')

    def _compute_new_applicant_count(self):
        pass

    def _compute_recruitment_stats(self):
        pass