from odoo import api, fields, models, tools, SUPERUSER_ID,_
import base64   
import fitz
import nltk
import re
from bs4 import BeautifulSoup
import requests
import linkedin
import json


AVAILABLE_PRIORITIES = [
    ('0', 'Normal'),
    ('1', 'Good'),
    ('2', 'Very Good'),
    ('3', 'Excellent')
]
class Applicant(models.Model):
    _name = "prediction.applicant"
    _description = "Applicant"
    _inherit = ['mail.thread.cc',
               'mail.thread.main.attachment',
               'mail.thread.blacklist',
               'mail.thread.phone',
               'mail.activity.mixin',
               'utm.mixin']
    _mailing_enabled = True
    _primary_email = 'email_from'

    name = fields.Char("Subject / Application",default="New Applicant", help="Email subject for applications sent via email", index='trigram')
    active = fields.Boolean("Active", default=True, help="If the active field is set to false, it will allow you to hide the case without removing it.")
    partner_id = fields.Many2one('res.partner', "Contact", copy=False)
    # application_id=fields.Many2one('website.applicant')
    partner_name=fields.Char("Applicant's Name")
    email_from = fields.Char("Email",store=True)
    partner_phone=fields.Char("Phone Number")
    partner_mobile=fields.Char("Mobile Numer")
    linkedin_profile=fields.Char("LinkedIn Profile")
    type_id = fields.Char(string="degree")
    interviewer_ids=fields.Selection([('hr','HR'),('senior_developer','Senior Developer')])
    meeting_display_text=fields.Char()
    meeting_display_date=fields.Char()
    medium_id = fields.Many2one(ondelete='set null')
    source_id = fields.Many2one(ondelete='set null')
    availability = fields.Date("Availability", help="The date at which the applicant will be available to start working", tracking=True)
    resume_detail= fields.Char()
    resume = fields.Many2many('ir.attachment', string="Attachments")
    description=fields.Html("Description")
    stage_id = fields.Many2one('prediction.stage', 'Stage', ondelete='restrict', tracking=True,
                               compute='_compute_stage', store=True, readonly=False,
                               domain="['|', ('job_ids', '=', False), ('job_ids', '=', job_id)]",
                               copy=False, index=True,
                               group_expand='_read_group_stage_ids')
    job_id = fields.Many2one('job.posting', "Applied Job", domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]", tracking=True, index=True)
    attachment_ids = fields.One2many('ir.attachment', 'res_id', domain=[('res_model', '=', 'prediction.applicant')], string='Attachments')
    work_sample=fields.Text()
    reason=fields.Text()
    reference=fields.Char()
    shift_time_id=fields.Selection([
                                    ('8am to 2pm', '(8am to 2pm)'),
                                    ('2pm to 9pm', '(2pm to 9pm)'),
                                    ('9pm to 3am', '(9pm to 3am)')])
    color = fields.Integer("Color Index", default=0)
    priority = fields.Selection(AVAILABLE_PRIORITIES, "Evaluation", default='0')
    department_id = fields.Many2one(
        'hr.department', "Department",  store=True, readonly=False,
        domain="['|', ('company_id', '=', False), ('company_id', '=', company_id)]", tracking=True)
    attachment_number = fields.Integer(string="Number of Attachments")
    application_status = fields.Selection([
        ('ongoing', 'Ongoing'),
        ('hired', 'Hired'),
        ('refused', 'Refused'),
        ('archived', 'Archived'),
        ('refused_by_pdf','refuse by pdf')
    ], compute="_compute_application_status")
    references=fields.Char(string="reference")
    company_id = fields.Many2one('res.company', "Company",compute='_compute_company', store=True, readonly=False, tracking=True)
    applicant_properties = fields.Properties('Properties', definition='job_id.applicant_properties_definition', copy=True)
    extracted_keywords = fields.Text(string="Extracted Keywords")
    current_address = fields.Char(string="current address")
    new_field_name=fields.Char(string="Education Field's Name")
    new_study_field=fields.Char(string="Study Field")
    new_organization=fields.Char(string="Organization's Name")
    new_start_date=fields.Date(string="start date")
    new_end_date=fields.Date(string="end date")
    new_grade=fields.Char(string="grade")
    new_name=fields.Char(string="role of profession")
    new_desc=fields.Text(string="description of profession")
    new_p_start_date=fields.Date(string="start date of profession's")
    new_p_end_date=fields.Date(string="end date of profession's")
    new_p_organization=fields.Char(string="profession's organization")
    create_date = fields.Datetime("Applied on", readonly=True)
    date_closed = fields.Datetime("Hire Date", compute='_compute_date_closed', store=True, readonly=False, tracking=True)
    date_open = fields.Datetime("Assigned", readonly=True)
    refuse_reason_id = fields.Many2one('refuse.reason', 'Refuse Reason')
    emp_id = fields.Many2one('hr.employee', string="Employee", help="Employee linked to the applicant.", copy=False)
    date_last_stage_update=fields.Date('Last Date')
    refused_by_pdf=fields.Char()

    
    def create_employee_from_applicant(self):
        """ Create an employee from applicant """
        self.ensure_one()
        self._check_interviewer_access()

        if not self.partner_id:
            if not self.partner_name:
                raise UserError(_('Please provide an applicant name.'))
            self.partner_id = self.env['res.partner'].create({
                'is_company': False,
                'name': self.partner_name,
                'email': self.email_from,
            })

    def toggle_active(self):
        self = self.with_context(just_unarchived=True)
        res = super(Applicant, self).toggle_active()
        active_applicants = self.filtered(lambda applicant: applicant.active)
        if active_applicants:
            active_applicants.reset_applicant()
        return res

    def reset_applicant(self):
        """ Reinsert the applicant into the recruitment pipe in the first stage"""
        default_stage = dict()
        for job_id in self.mapped('job_id'):
            default_stage[job_id.id] = self.env['prediction.stage'].search(
                [
                    '|',
                    ('job_ids', '=', False),
                    ('job_ids', '=', job_id.id),
                    ('fold', '=', False)
                ], order='sequence asc', limit=1).id
        for applicant in self:
            applicant.write(
                {'stage_id': applicant.job_id.id and default_stage[applicant.job_id.id],
                 'refuse_reason_id': False})

    def action_open_employee(self):
        pass

    def action_applications_email(self):
        pass

    def action_makeMeeting(self):
        self.ensure_one()
        if not self.partner_id:
            if not self.partner_name:
                raise UserError(_('You must define a Contact Name for this applicant.'))
            self.partner_id = self.env['res.partner'].create({
                'is_company': False,
                'name': self.partner_name,
                'email': self.email_from,
            })
    @api.depends('stage_id.hired_stage')
    def _compute_date_closed(self):
        for applicant in self:
            if applicant.stage_id and applicant.stage_id.hired_stage and not applicant.date_closed:
                applicant.date_closed = fields.datetime.now()
            if not applicant.stage_id.hired_stage:
                applicant.date_closed = False

    @api.depends('refuse_reason_id','date_closed')
    def _compute_application_status(self):
        for applicant in self:
            if applicant.refuse_reason_id:
                applicant.application_status = 'refused'
            elif not applicant.active:
                applicant.application_status = 'archived'
            elif applicant.date_closed:
                applicant.application_status = 'hired'
            elif applicant.refused_by_pdf:
                applicant.application_status = 'refused'
            else:
                applicant.application_status = 'ongoing'
           
    def action_open_attachments(self):
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'ir.attachment',
            'name': _('Documents'),
            'context': {
                'default_res_model': 'hr.job',
                'default_res_id': self.ids[0],
                'show_partner_name': 1,
            },
            'view_mode': 'tree,form',
            'views': [
                (self.env.ref('prediction.ir_attachment_job_posting_list_view').id, 'tree'),
                (False, 'form'),
            ],
            'search_view_id': self.env.ref('prediction.ir_attachment_view_search_inherit_hr_recruitment').ids,
            'domain': [('res_model', '=', 'prediction.applicant'), ('res_id', 'in', self.ids), ],
        }
   
    def archive_applicant(self):
        return {
            'type': 'ir.actions.act_window',
            'name': _('Refuse Reason'),
            'res_model': 'get.refuse.reason',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_applicant_ids': self.ids, 'active_test': False},
            'views': [[False, 'form']]
        }

    def extract_text_from_pdf(self):
        skill_set = {'python', 'java', 'javascript', 'sql', 'html', 'css', 'react', 'angular', 'node.js', 'c', 'c++', 'c#', 'ruby', 'php', 'swift', 'typescript', 'django', 'flask', 'express.js', 'mongodb', 'mysql', 'postgresql', 'redis', 'git', 'docker', 'kubernetes', 'aws', 'azure', 'google cloud', 'linux', 'unix', 'bash', 'nginx', 'apache', 'rest', 'graphql', 'json', 'xml', 'oop', 'mvc', 'design patterns', 'agile', 'scrum', 'kanban', 'git', 'svn'}

        for applicant in self:
            for attachment in applicant.resume:
                if attachment.mimetype == 'application/pdf':
                    pdf_data = base64.b64decode(attachment.datas)
                    doc = fitz.open(stream=pdf_data, filetype="pdf")
                    text = ""

                    # Search for the "Resume" section and extract text from that section
                    for page_num in range(len(doc)):
                        page = doc.load_page(page_num)
                        page_text = page.get_text()
                        if re.search(r'Resume', page_text, re.IGNORECASE):
                            text += page_text

                    doc.close()

                    # Tokenize the text into words
                    words = nltk.word_tokenize(text)

                    # Extract skills based on the predefined set
                    skills = {word.lower() for word in words if word.lower() in skill_set}

                    # Write the extracted skills into the 'extracted_keywords' field
                    if skills:
                        applicant.write({'extracted_keywords': ', '.join(skills)})
                        print('000000000000000',applicant.extracted_keywords)
                        return {
                            'name': _('Skills Extraction successfully'),
                            'type': 'ir.actions.client',
                            'tag': 'display_notification',
                            'params': {
                                'title': _('Skill matched'),
                                'type': 'success',
                                'message': _('Applicant has the required skills.'),
                                'sticky': False
                            }
                        }
                    else:
                        applicant.write({'application_status': 'refused_by_pdf'})
                        return {
                            'name': _('Skills Extraction Failed'),
                            'type': 'ir.actions.client',
                            'tag': 'display_notification',
                            'params': {
                                'title': _('Skill unmatch'),
                                'type': 'danger',
                                'message': _('Applicant does not have the required skills.'),
                                'sticky': False
                            }
                        }



    @api.depends('job_id')
    def _compute_stage(self):
        for applicant in self:
            if applicant.job_id:
                if not applicant.stage_id:
                    stage_ids = self.env['prediction.stage'].search([
                        '|',
                        ('job_ids', '=', False),
                        ('job_ids', '=', applicant.job_id.id),
                        ('fold', '=', False)
                    ], order='sequence asc', limit=1).ids
                    applicant.stage_id = stage_ids[0] if stage_ids else False
            else:
                applicant.stage_id = False


    @api.model
    def _read_group_stage_ids(self, stages, domain, order):
        # retrieve job_id from the context and write the domain: ids + contextual columns (job or default)
        job_id = self._context.get('default_job_id')
        search_domain = [('job_ids', '=', False)]
        if job_id:
            search_domain = ['|', ('job_ids', '=', job_id)] + search_domain
        if stages:
            search_domain = ['|', ('id', 'in', stages.ids)] + search_domain

        stage_ids = stages._search(search_domain, order=order, access_rights_uid=SUPERUSER_ID)
        return stages.browse(stage_ids)

    @api.onchange('job_id')
    def _onchange_job_id(self):
        for applicant in self:
            if applicant.job_id.name:
                applicant.name = applicant.job_id.name


    @api.depends('job_id', 'department_id')
    def _compute_company(self):
        for applicant in self:
            company_id = False
            if applicant.department_id:
                company_id = applicant.department_id.company_id.id
            if not company_id and applicant.job_id:
                company_id = applicant.job_id.company_id.id
            applicant.company_id = company_id or self.env.company.id
    
    def extract_linkedin_info(self):
        extracted_data = {}
        # Replace 'YOUR_ACCESS_TOKEN' with your actual access token
        access_token = 'AQXzmlE78q_CH53sYtsNoMHZjQTRBrQhDCZAudYNC8oy2pCyf7yXMO3sqvVM_GvxfeEnA6DpEmcovrbymdixav4wR8mo_NOZXsod6XnYZbfZ2sr60Bd-0bGyRp7HhSBy6DCx1G5TAJFoT3ADcOXNl93Zs2epekj6ne-P57nQ_88Qy2UjHOV4BFjJYRx9ujk_en26hBtykPUdierXtkbszEVDmwpnFU4Cre_JP1i3ZR6T5ont5mZM2F6TcoGeHo6ZFRpIvfplh6jzndHKSI5atev9iOP-VVEbn4KGnouPuOLkmwTfj6iK5JM2DAfHbXF5Ll6YoKQCTnK8_6uWFyyQJ8ZBw6S0JQ'

        for applicant in self:
            if applicant.linkedin_profile:
                # LinkedIn People API endpoint for fetching user data
                endpoint = f'https://api.linkedin.com/v2/people/{applicant.linkedin_profile}'

                # Set up headers with the access token
                headers = {
                    'Authorization': f'Bearer {access_token}',
                    'Connection': 'Keep-Alive',
                }

                try:
                    # Make a GET request to fetch user data
                    response = requests.get(endpoint, headers=headers)
                    response_json = response.json()

                    # Extract name and skills
                    name = response_json.get('firstName', '') + ' ' + response_json.get('lastName', '')
                    skills = [skill.get('name', '') for skill in response_json.get('skills', {}).get('values', [])]

                    extracted_data[applicant.id] = {'name': name, 'extracted_keywords': ', '.join(skills)}
                except Exception as e:
                    print(f"Failed to retrieve data from LinkedIn profile for applicant {applicant.id}: {e}")

        return extracted_data

    def trigger_linkedin_extraction(self):
        extracted_data = self.extract_linkedin_info()  # Call the extraction function
        if extracted_data:  # Check if data was extracted
            for applicant_id, data in extracted_data.items():
                # Process the extracted data (e.g., update applicant fields)
                print("Applicant ID:", applicant_id)
                print("Extracted Data:", data)
        else:
            print("No data extracted from LinkedIn profiles.")

    def cron_trigger_linkedin_extraction(self):
        self.trigger_linkedin_extraction()

# Usage
if __name__ == "__main__":
    applicant_db = Applicant()
    applicant_db.cron_trigger_linkedin_extraction()





    
