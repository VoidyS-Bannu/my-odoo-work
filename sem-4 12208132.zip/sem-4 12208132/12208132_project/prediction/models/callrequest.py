# models/call_request.py

from odoo import models, fields

class CallRequest(models.Model):
    _name = 'applicant.call.request'
    _description = 'Applicant Call Request'

    applicant_id = fields.Many2one('prediction.applicant', string='Applicant', required=True)
    name = fields.Char(string='Name', required=True)
    phone = fields.Char(string='Phone')
    email = fields.Char(string='email')
    preferred_time = fields.Datetime(string='Preferred Time')
    call_description=fields.Text(String='call regarding')
