from odoo import models,fields

class skill(models.Model):
	_name="skill.report"
	_description="skill report"