# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
from odoo import http
from odoo.http import request
import base64  
from werkzeug.utils import secure_filename

class Job(http.Controller):
    _jobs_per_page = 12    

    def sitemap_jobs(env, rule, qs):
        if not qs or qs.lower() in '/jobs':
            yield {'loc': '/jobs'}

    @http.route([
        '/jobs',
        '/jobs/page/<int:page>',
    ], type='http', auth="public", website=True, sitemap=sitemap_jobs)
    def jobs(self, page=1):
        env = request.env(context=dict(request.env.context, show_address=True, no_tag_br=True))

        Jobs = env['job.posting']

        # Get all published jobs (adjust filtering if needed)
        jobs = Jobs.search([('is_published', '=', True)])

        # Pagination
        pager = request.website.pager(
            url=request.httprequest.path.partition('/page/')[0],
            url_args=request.httprequest.args,
            total=len(jobs),
            page=page,
            step=self._jobs_per_page,
        )
        offset = pager['offset']
        jobs = jobs[offset:offset + self._jobs_per_page]

        # Render page
        return request.render("prediction_website.index", {
            'jobs': jobs,
            'pager': pager,
        })

    @http.route('''/jobs/apply/<model("job.posting"):job>''', type='http', auth="public", website=True, sitemap=True, csrf=True)
    def job_apply(self,job, **kw):
        error = {}
        default = {}
        if 'website_hr_recruitment_error' in request.session:
            error = request.session.pop('website_hr_recruitment_error')
            default = request.session.pop('website_hr_recruitment_default')
        return request.render("prediction_website.apply", {
            'job': job,
            'error': error,
            'default': default,
        })

    @http.route('''/jobs/detail/<model("job.posting"):job>''', type='http', auth="public", website=True, sitemap=True)
    def jobs_details(self, job, **kwargs):
        redirect_url = f"/jobs/{slug(job)}"
        return request.redirect(redirect_url, code=301)

    @http.route('''/jobs/<model("job.posting"):job>''', type='http', auth="public", website=True, sitemap=True)
    def job(self, job, **kwargs):
        return request.render("prediction_website.detail", {
            'job': job,
            'main_object': job,
        })

    @http.route('/prediction_website/check_recent_application', type='json', auth="public")
    def check_recent_application(self, email, job_id):
        date_limit = datetime.now() - timedelta(days=90)
        domain = [('email_from', '=ilike', email),('create_date', '>=', date_limit)]
        recent_applications = http.request.env['prediction.applicant'].sudo().search(domain)
        response = {'applied_same_job': any(a.job_id.id == int(job_id) if job_id else False for a in recent_applications)}
        return response

    @http.route([
        '/jobs/country/<model("res.country"):country>',
        '/jobs/department/<model("hr.department"):department>',
        '/jobs/country/<model("res.country"):country>/department/<model("hr.department"):department>',
        '/jobs/office/<int:office_id>',
        '/jobs/country/<model("res.country"):country>/office/<int:office_id>',
        '/jobs/department/<model("hr.department"):department>/office/<int:office_id>',
        '/jobs/country/<model("res.country"):country>/department/<model("hr.department"):department>/office/<int:office_id>',
        '/jobs/employment_type/<int:contract_type_id>',
        '/jobs/country/<model("res.country"):country>/employment_type/<int:contract_type_id>',
        '/jobs/department/<model("hr.department"):department>/employment_type/<int:contract_type_id>',
        '/jobs/office/<int:office_id>/employment_type/<int:contract_type_id>',
        '/jobs/country/<model("res.country"):country>/department/<model("hr.department"):department>/employment_type/<int:contract_type_id>',
        '/jobs/country/<model("res.country"):country>/office/<int:office_id>/employment_type/<int:contract_type_id>',
        '/jobs/department/<model("hr.department"):department>/office/<int:office_id>/employment_type/<int:contract_type_id>',
        '/jobs/country/<model("res.country"):country>/department/<model("hr.department"):department>/office/<int:office_id>/employment_type/<int:contract_type_id>',
    ], type='http', auth="public", website=True, sitemap=False)
    def jobs_compatibility(self, country=None, department=None, office_id=None, contract_type_id=None, **kwargs):
        """
        Deprecated since Odoo 16.3: those routes are kept by compatibility.
        They should not be used in Odoo code anymore.
        """
        warnings.warn(
            "This route is deprecated since Odoo 16.3: the jobs list is now available at /jobs or /jobs/page/XXX",
            DeprecationWarning
        )
        return self.jobs(
            country_id=country.id if country else None,
            department_id=department.id if department else None,
            office_id=office_id,
            contract_type_id=contract_type_id,
            **kwargs
        )


    # @http.route('/description',auth='public',website=True)
    # def description(self,**kw):
    #     return http.request.render('prediction_website.default_website_description',{})

    # @http.route('/website/form/', type="http", auth="public", website=True, method=['POST'], csrf=False)
    # def create_applicant(self,**kw):
    #     print("Data received:", kw)

    #     if request.httprequest.method == 'POST' and request.httprequest.files.get('resume'):
    #         resume = request.httprequest.files['resume']
    #         resume_content = resume.read()

    #         data = {
    #             'job_id':kw.get('job_id'),
    #             'name': kw.get('applicationname'),
    #             'partner_name': kw.get('partner_name'),
    #             'email_from': kw.get('email_from'),
    #             'partner_phone': kw.get('partner_phone'),
    #             'current_address': kw.get('current_address'),
    #             'reason': kw.get('reason'),
    #             'work_sample': kw.get('work_sample'),
    #             'resume': [(0, 0, {'name': 'resume.pdf', 'res_model': 'prediction.applicant', 'datas': base64.b64encode(resume_content).decode()})],
    #             'linkedin_profile': kw.get('linkedin_profile'),
    #             'shift_time_id': kw.get('shift_time_id'),
    #             'references': kw.get('references'),
    #             'new_field_name': kw.get('new_field_name'),
    #             'new_study_field': kw.get('new_study_field'),
    #             'new_organization': kw.get('new_organization'),
    #             'new_start_date': kw.get('new_start_date'),
    #             'new_end_date': kw.get('new_end_date'),
    #             'new_grade': kw.get('new_grade'),
    #             'new_p_organization': kw.get('new_p_organization'),
    #             'new_name': kw.get('new_name'),
    #             'new_desc': kw.get('new_desc'),
    #             'new_p_start_date': kw.get('new_p_start_date'),
    #             'new_p_end_date': kw.get('new_p_end_date'),
    #         }

    #         from_id = request.env['prediction.applicant'].sudo().create(data)

    #         return request.render('prediction_website.apply', {})

        # else:
        #     # Handle the case where there's no file uploaded
        #     return http.request.render('prediction_website.error_page', {'error_message': 'No resume file uploaded.'})
    
    @http.route('/call/request',type='http', auth='public', website=True , csrf=False)
    def call_request_page(self, **kw):
        print("Data received:", kw)
        if kw.get('applicant_id'):  # Check if applicant_id is provided
            try:
                # Get the applicant ID from the form data
                applicant_id = int(kw.get('applicant_id'))

                # Prepare data for creating the call request record
                data = {
                    'applicant_id': applicant_id,
                    'name': kw.get('name'),
                    'phone': kw.get('phone'),
                    'email': kw.get('email'),
                    'preferred_time': kw.get('preferred_time'),
                    'call_description': kw.get('call_description')
                }

                # Create the call request record
                form_id = request.env['applicant.call.request'].sudo().create(data)

            except ValueError:
                # Handle invalid applicant_id (empty string or non-integer value)
                # Log or handle the error as needed
                pass

        return request.render('prediction_website.call_request_page_template', {})
