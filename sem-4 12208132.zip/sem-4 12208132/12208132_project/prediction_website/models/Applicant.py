# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import models,fields
from odoo.exceptions import UserError


class Applicant(models.Model):
    _name='website.applicant'
    _inherit = 'prediction.applicant'
    _description='website applicant'

    # data_ids=fields.One2many('prediction.applicant','application_id')