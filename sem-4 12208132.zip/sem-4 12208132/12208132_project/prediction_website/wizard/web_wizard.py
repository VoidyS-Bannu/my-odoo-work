from odoo import models, fields, api

class CallRequestWizard(models.TransientModel):
    _name = 'call.wizard'
    _description = 'Call Request Wizard'

    _inherit = 'applicant.call.request'  # Inherit the normal model
    
       
    def send_call_request(self):
        self.env['applicant.call.request'].create({
            'name': self.name,
            'phone': self.phone,
            'email': self.email,
            'preferred_time': self.preferred_time,
            'call_description': self.call_description
        })
        return {'type': 'ir.actions.act_window_close'}
