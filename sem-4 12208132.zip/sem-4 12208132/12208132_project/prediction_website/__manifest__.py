# -*- coding: utf-8 -*-
{
    'name': "prediction_website",

    'summary': "This website'll collect candidate information",

    'description': """
Long description of module's purpose
    """,

    'author': "prediction",
    'website': "https://www.prediction.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/15.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['prediction','website_mail'],

    # always loaded
    'data': [
          'security/ir.model.access.csv',
          'views/job_views.xml',
          'views/template.xml',
          'views/web_page_view.xml',
          'views/recruitment_view.xml',
          'data/config_data.xml',
          'wizard/web_wizard.xml'
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],

    'assets': {
        'web.assets_frontend': [
            'prediction_website/static/src/scss/**/*',
            'prediction_website/static/src/applicant_form.js',
            'prediction_website/static/src/js/prediction_form.js'
        ],
        'website.assets_wysiwyg': [
            'prediction_website/static/src/js/prediction_editor.js',
        ],
        'website.assets_editor': [
            'prediction_website/static/src/js/systray_items/new_content.js',
        ],
        'web.assets_tests': [
            'prediction_website/static/tests/**/*',
        ],
        
    },
}

